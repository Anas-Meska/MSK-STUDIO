const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.querySelector('.container');

signUpButton.addEventListener('click', () => {
    container.classList.add('right-panel-active');
});

signInButton.addEventListener('click', () => {
    container.classList.remove('right-panel-active');
});

document.getElementById('signupForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const confirmpassword = document.getElementById('signupConfirmPassword').value;

    
    console.log('Inscription:', { name, email, password });
    setTimeout(() => {
        window.location.href = 'home.html'; 
    }, 1000); 
});

document.getElementById('signinForm').addEventListener('submit', (e) => {
    e.preventDefault();
    const email = document.getElementById('signinEmail').value;
    const password = document.getElementById('signinPassword').value;

    
    console.log('Connexion:', { email, password });
    setTimeout(() => {
        window.location.href = 'index.html'; 
    }, 1000); 
});